<?php 
 $GLOBALS["dictionary"]["User"]["fields"]["address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["User"]["fields"]["address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["User"]["fields"]["address_country"]["options"] = 'countries_dom';
?>

 