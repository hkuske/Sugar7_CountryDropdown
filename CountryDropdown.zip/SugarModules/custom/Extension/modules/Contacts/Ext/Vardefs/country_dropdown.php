<?php 
 $GLOBALS["dictionary"]["Contact"]["fields"]["primary_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Contact"]["fields"]["primary_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Contact"]["fields"]["primary_address_country"]["options"] = 'countries_dom';

 $GLOBALS["dictionary"]["Contact"]["fields"]["alt_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Contact"]["fields"]["alt_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Contact"]["fields"]["alt_address_country"]["options"] = 'countries_dom';
?>

 