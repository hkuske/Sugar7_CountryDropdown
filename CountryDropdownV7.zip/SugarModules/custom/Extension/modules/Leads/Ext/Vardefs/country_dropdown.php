<?php 
 $GLOBALS["dictionary"]["Lead"]["fields"]["primary_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Lead"]["fields"]["primary_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Lead"]["fields"]["primary_address_country"]["options"] = 'countries_dom';

 $GLOBALS["dictionary"]["Lead"]["fields"]["alt_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Lead"]["fields"]["alt_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Lead"]["fields"]["alt_address_country"]["options"] = 'countries_dom';
?>

 