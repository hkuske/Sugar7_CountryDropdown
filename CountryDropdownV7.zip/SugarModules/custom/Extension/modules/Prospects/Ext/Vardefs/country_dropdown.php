<?php 
 $GLOBALS["dictionary"]["Prospect"]["fields"]["primary_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Prospect"]["fields"]["primary_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Prospect"]["fields"]["primary_address_country"]["options"] = 'countries_dom';

 $GLOBALS["dictionary"]["Prospect"]["fields"]["alt_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Prospect"]["fields"]["alt_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Prospect"]["fields"]["alt_address_country"]["options"] = 'countries_dom';
?>

 