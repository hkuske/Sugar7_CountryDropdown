<?php 
 $GLOBALS["dictionary"]["Account"]["fields"]["billing_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Account"]["fields"]["billing_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Account"]["fields"]["billing_address_country"]["options"] = 'countries_dom';

 $GLOBALS["dictionary"]["Account"]["fields"]["shipping_address_country"]["type"] = 'enum';
 $GLOBALS["dictionary"]["Account"]["fields"]["shipping_address_country"]["massupdate"] = true;
 $GLOBALS["dictionary"]["Account"]["fields"]["shipping_address_country"]["options"] = 'countries_dom';
?>

 